exports.handler = async (event) => {
  try {
    console.log("Event:", JSON.stringify(event));
    
    // Log environment variables
    console.log("Environment:", {
      EVENT_BUCKET_NAME: process.env.EVENT_BUCKET_NAME,
      EVENT_BUS_NAME: process.env.EVENT_BUS_NAME,
      EVENT_DLQ_URL: process.env.EVENT_DLQ_URL,
      AWS_ENDPOINT_URL: process.env.AWS_ENDPOINT_URL
    });
    
    // Test AWS SDK functionality
    const AWS = require('aws-sdk');
    if (process.env.AWS_ENDPOINT_URL) {
      AWS.config.update({
        endpoint: process.env.AWS_ENDPOINT_URL
      });
    }
    
    // Try a simple S3 operation
    const s3 = new AWS.S3();
    try {
      const buckets = await s3.listBuckets().promise();
      console.log("S3 Buckets:", buckets);
    } catch (s3Error) {
      console.error("S3 Error:", s3Error);
    }
    
    return { 
      statusCode: 200, 
      body: JSON.stringify({ message: "Success" }) 
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message, stack: error.stack })
    };
  }
};
